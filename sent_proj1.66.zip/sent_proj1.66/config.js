module.exports = {
    consumer_key: 'x3Gj4SsjnqTHVz9lAqLCQZdIY',
    consumer_secret: 'ibRmescdN1p2te24nxGBm1Z7coQO2CVJDNwTwx4JDyRzjdyUwh',
    access_token: '3356957645-e6EtOVzTtie8AhJYwDNt3Di7Hjcmfj5Yfl5D5ci',
    access_token_secret: 'OnFPkMsNXZ4qW412rbeGphVZ5FRRFf2PzA2UV9HCFFhc9',
}
